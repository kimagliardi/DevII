//Nomes: Kim Agliardi, Saymon Andres
public class Pedido{
	Frete frete;
	private List itensPedido;
	private int tipoFrete; 

	public pedido(List itens, int tipoFrete){
		this.ites = itens;
		this.tipoFrete = tipoFrete;
	}

	public void setTipoFrete(Frete frete){
		this.frete = frete;
	}

	public void ajusteFrete(){
		frete.calcFrete();
	}

	public int getFrete(){
		return this.frete;
	}


}