//Nomes: Kim Agliardi, Saymon Andres
public interface Frete { public double calcFrete(); }

private double total = 0; 

public class TipoFrete1 implements Frete {
	public double calcFrete(){
		//op de cálculo I
		return total;
	}
public class TipoFrete2 implements Frete {
		public double calcFrete(){
			//op de cálculo II
		return total;
		}
	}
public class TipoFrete3 implements Frete {
		//op de cálculo II
		return total;
	}
}