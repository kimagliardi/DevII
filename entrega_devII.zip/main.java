//Nomes: Kim Agliardi, Saymon Andres

public class Main{
	public static void main(Strings[] args){

		Pedido p1 = new Pedido (itens, tipoFrete);
		Pedido p2 = new Pedido (itens, tipoFrete);


		p1.setTipoFrete(new TipoFrete1());
		p1.ajusteFrete();

		p2.setTipoFrete(new TipoFrete3());
		p2.ajusteFrete();

		p1.setTipoFrete(new TipoFrete2());
		p1.ajusteFrete();
	}
}